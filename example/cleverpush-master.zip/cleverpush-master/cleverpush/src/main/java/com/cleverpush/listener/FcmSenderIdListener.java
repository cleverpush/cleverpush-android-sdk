package com.cleverpush.listener;

public interface FcmSenderIdListener {
    void complete(String gcmSenderId);
}
