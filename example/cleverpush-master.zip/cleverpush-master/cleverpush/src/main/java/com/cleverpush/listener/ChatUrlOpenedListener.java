package com.cleverpush.listener;

public interface ChatUrlOpenedListener {
    void opened(String url);
}
