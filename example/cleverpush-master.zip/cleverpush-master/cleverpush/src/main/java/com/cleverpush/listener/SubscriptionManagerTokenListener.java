package com.cleverpush.listener;

public interface SubscriptionManagerTokenListener {
    void ready(String token);
}
