package com.cleverpush.listener;

public interface CompletionListener {
    void onComplete();
}
