package com.cleverpush.listener;

public interface AppBannerUrlOpenedListener {
    void opened(String url);
}
