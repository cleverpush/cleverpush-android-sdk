package com.cleverpush.listener;

import com.cleverpush.NotificationOpenedResult;

public interface NotificationOpenedListener {
    void notificationOpened(NotificationOpenedResult result);
}
