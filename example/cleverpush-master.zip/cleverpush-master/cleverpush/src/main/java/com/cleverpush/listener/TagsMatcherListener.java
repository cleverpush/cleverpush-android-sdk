package com.cleverpush.listener;

public interface TagsMatcherListener {
    void tagMatches(boolean matches);
}
