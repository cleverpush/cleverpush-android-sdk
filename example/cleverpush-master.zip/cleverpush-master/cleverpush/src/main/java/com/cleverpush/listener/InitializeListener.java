package com.cleverpush.listener;

public interface InitializeListener {
    void onInitialized();
}
