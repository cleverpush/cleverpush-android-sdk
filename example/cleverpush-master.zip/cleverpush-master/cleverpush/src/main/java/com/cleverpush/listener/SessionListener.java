package com.cleverpush.listener;

public interface SessionListener {
    public void stateChanged(boolean open);

}
