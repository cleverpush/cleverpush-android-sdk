package com.cleverpush.listener;

import com.cleverpush.banner.models.BannerAction;

public interface AppBannerOpenedListener {
    void opened(BannerAction action);
}
