package com.cleverpush.listener;

public interface NegativeReviewListener {
    void onNegativeReview(int stars);
}
