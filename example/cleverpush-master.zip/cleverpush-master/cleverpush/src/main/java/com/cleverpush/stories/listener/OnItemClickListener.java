package com.cleverpush.stories.listener;

import androidx.recyclerview.widget.RecyclerView;

public interface OnItemClickListener {

        void onClicked(int position);

    }
