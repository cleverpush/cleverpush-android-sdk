package com.cleverpush.listener;

public interface ActivityInitializedListener {
    public void initialized();
}
