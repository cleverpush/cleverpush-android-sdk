package com.cleverpush.listener;

public interface SubscribedListener {
    void subscribed(String subscriptionId);
}
