package com.cleverpush.stories.listener;

public interface OnSwipeDownListener {

        void onSwipeDown();
        
    }
