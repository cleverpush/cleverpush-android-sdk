package com.cleverpush.listener;

public interface TrackingConsentListener {
    void ready();
}
