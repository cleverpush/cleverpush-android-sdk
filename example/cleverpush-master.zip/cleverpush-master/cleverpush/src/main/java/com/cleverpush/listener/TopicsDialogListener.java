package com.cleverpush.listener;

public interface TopicsDialogListener {
    void callback(boolean accepted);
}
