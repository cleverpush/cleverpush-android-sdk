package com.cleverpush.stories;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

class StoryViewHolder extends RecyclerView.ViewHolder {

        public StoryViewHolder(View itemView) {
            super(itemView);
        }

    }
