package com.cleverpush.listener;

import com.cleverpush.Notification;

public interface NotificationClickListener {
    void onClicked(Notification notification);
}
