package com.cleverpush.listener;

import java.util.Set;

public interface AddTagCompletedListener {
    void tagAdded(int currentPositionOfTagToAdd);
}
