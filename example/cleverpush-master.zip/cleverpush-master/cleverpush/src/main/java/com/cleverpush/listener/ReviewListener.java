package com.cleverpush.listener;

public interface ReviewListener {
    void onReview(int stars);
}
