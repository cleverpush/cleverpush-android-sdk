package com.cleverpush.inbox;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

class InboxViewHolder extends RecyclerView.ViewHolder {
    public InboxViewHolder(View itemView) {
        super(itemView);
    }
}
