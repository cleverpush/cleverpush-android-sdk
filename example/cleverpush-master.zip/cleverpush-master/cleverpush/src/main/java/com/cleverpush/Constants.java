package com.cleverpush;

public interface Constants {
    String LOG_TAG = "CleverPush";
}
