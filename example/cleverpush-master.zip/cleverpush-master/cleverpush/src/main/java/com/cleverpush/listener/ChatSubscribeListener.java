package com.cleverpush.listener;

public interface ChatSubscribeListener {
    void subscribe();
}
